'use client';
import { useState, useEffect } from 'react';
import useSWR from 'swr';
import AppShell from '@/components/layout/AppShell';
import { PageHeader, Input } from '@/components/ui/components';
import { Save, Upload } from 'lucide-react';
import { getErrorMessage } from '@/lib/utils';
import api from '@/lib/api';
import toast from 'react-hot-toast';

const fetcher = (url: string) => api.get(url).then((r) => r.data);

export default function SettingsPage() {
  const { data, isLoading, mutate } = useSWR('/settings', fetcher);
  const [form, setForm] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => { if (data) setForm(data); }, [data]);

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function save(e: React.FormEvent) {
    e.preventDefault(); setSaving(true);
    try {
      await api.put('/settings', form);
      toast.success('Settings saved');
      mutate();
    } catch (e) { toast.error(getErrorMessage(e)); }
    finally { setSaving(false); }
  }

  async function uploadLogo() {
    if (!logoFile) return; setUploading(true);
    try {
      const fd = new FormData(); fd.append('logo', logoFile);
      const { data } = await api.post('/upload/logo', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Logo uploaded');
      setForm((f) => ({ ...f, logo_url: data.logoUrl }));
      mutate();
    } catch (e) { toast.error(getErrorMessage(e)); }
    finally { setUploading(false); setLogoFile(null); }
  }

  if (isLoading) return <AppShell><div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent" /></div></AppShell>;

  return (
    <AppShell>
      <PageHeader title="Settings" subtitle="Configure your business details and system preferences" />
      <form onSubmit={save} className="space-y-6 max-w-2xl">
        <div className="card">
          <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">Business Information</h2>
          <div className="space-y-4">
            <Input label="Business Name" value={form.business_name || ''} onChange={(e) => set('business_name', e.target.value)} />
            <Input label="Address" value={form.business_address || ''} onChange={(e) => set('business_address', e.target.value)} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Phone" value={form.business_phone || ''} onChange={(e) => set('business_phone', e.target.value)} />
              <Input label="Email" type="email" value={form.business_email || ''} onChange={(e) => set('business_email', e.target.value)} />
            </div>
            <Input label="GST Number" value={form.gst_number || ''} onChange={(e) => set('gst_number', e.target.value)} />
          </div>
        </div>

        <div className="card">
          <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">Invoice Settings</h2>
          <div className="grid grid-cols-3 gap-4">
            <Input label="Invoice Prefix" value={form.invoice_prefix || 'INV'} onChange={(e) => set('invoice_prefix', e.target.value)} placeholder="INV" />
            <Input label="Default Tax (%)" type="number" min="0" max="100" value={form.default_tax || '18'} onChange={(e) => set('default_tax', e.target.value)} />
            <div className="space-y-1">
              <label className="block text-sm font-medium text-gray-700">Currency Symbol</label>
              <select className="input" value={form.currency_symbol || '₹'} onChange={(e) => set('currency_symbol', e.target.value)}>
                <option value="₹">₹ INR</option>
                <option value="$">$ USD</option>
                <option value="€">€ EUR</option>
                <option value="£">£ GBP</option>
                <option value="AED">AED</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">Business Logo</h2>
          {form.logo_url && (
            <div className="mb-3">
              <img src={`${process.env.NEXT_PUBLIC_API_URL}${form.logo_url}`} alt="Logo" className="h-16 object-contain border border-gray-100 rounded-lg p-2" />
            </div>
          )}
          <div className="flex items-center gap-3">
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setLogoFile(e.target.files?.[0] || null)} className="input w-auto" />
            {logoFile && <button type="button" className="btn-secondary btn-sm" onClick={uploadLogo} disabled={uploading}>
              <Upload className="w-3.5 h-3.5" />{uploading ? 'Uploading...' : 'Upload'}
            </button>}
          </div>
        </div>

        <div className="flex justify-end">
          <button type="submit" className="btn-primary" disabled={saving}>
            <Save className="w-4 h-4" />{saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>
    </AppShell>
  );
}
