'use client';
import AppShell from '@/components/layout/AppShell';
import { StatCard } from '@/components/ui';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, Users, Wrench, AlertTriangle, FileText } from 'lucide-react';
import { formatCurrency, formatDate, STATUS_COLORS } from '@/lib/utils';
import useSWR from 'swr';
import api from '@/lib/api';

const fetcher = (url: string) => api.get(url).then((r) => r.data);

export default function DashboardPage() {
  const { data, isLoading } = useSWR('/dashboard', fetcher, { refreshInterval: 60000 });

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500">Overview of your business</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Today's Sales"
            value={isLoading ? '...' : formatCurrency(data?.todaySales?.amount || 0)}
            subtitle={`${data?.todaySales?.count || 0} invoices`}
            icon={<TrendingUp className="w-6 h-6" />}
            color="blue"
          />
          <StatCard
            title="Monthly Revenue"
            value={isLoading ? '...' : formatCurrency(data?.monthlyRevenue?.amount || 0)}
            subtitle={`${data?.monthlyRevenue?.count || 0} invoices`}
            icon={<FileText className="w-6 h-6" />}
            color="green"
          />
          <StatCard
            title="Active Repairs"
            value={isLoading ? '...' : data?.activeRepairs || 0}
            subtitle="In progress"
            icon={<Wrench className="w-6 h-6" />}
            color="yellow"
          />
          <StatCard
            title="Low Stock Alerts"
            value={isLoading ? '...' : data?.lowStockAlerts || 0}
            subtitle="Items need restocking"
            icon={<AlertTriangle className="w-6 h-6" />}
            color="red"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-base font-semibold text-gray-900 mb-4">Sales This Month</h2>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={data?.salesByDay || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(v) => new Date(v).getDate().toString()} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} />
                <Bar dataKey="total" fill="#2563eb" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card">
            <h2 className="text-base font-semibold text-gray-900 mb-4">Recent Repairs</h2>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="h-10 bg-gray-100 rounded animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {(data?.recentRepairs || []).map((r: any) => (
                  <div key={r.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{r.brand} {r.model}</p>
                      <p className="text-xs text-gray-500">{r.customer?.name} · {r.jobId}</p>
                    </div>
                    <span className={`badge ${STATUS_COLORS[r.status] || 'badge-gray'}`}>
                      {r.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                ))}
                {!data?.recentRepairs?.length && <p className="text-sm text-gray-400 text-center py-4">No active repairs</p>}
              </div>
            )}
          </div>
        </div>

        {/* Recent Invoices */}
        <div className="card">
          <h2 className="text-base font-semibold text-gray-900 mb-4">Recent Invoices</h2>
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="table-header">Invoice #</th>
                <th className="table-header">Customer</th>
                <th className="table-header">Total</th>
                <th className="table-header">Status</th>
                <th className="table-header">Date</th>
              </tr>
            </thead>
            <tbody>
              {isLoading
                ? Array.from({ length: 4 }).map((_, i) => (
                    <tr key={i}><td colSpan={5}><div className="h-8 bg-gray-100 rounded m-1 animate-pulse" /></td></tr>
                  ))
                : (data?.recentInvoices || []).map((inv: any) => (
                    <tr key={inv.id} className="table-row">
                      <td className="table-cell font-mono text-xs font-medium text-blue-600">{inv.number}</td>
                      <td className="table-cell">{inv.customer?.name}</td>
                      <td className="table-cell font-medium">{formatCurrency(inv.totalAmount)}</td>
                      <td className="table-cell"><span className={`badge ${STATUS_COLORS[inv.status]}`}>{inv.status}</span></td>
                      <td className="table-cell text-gray-400">{formatDate(inv.createdAt)}</td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
