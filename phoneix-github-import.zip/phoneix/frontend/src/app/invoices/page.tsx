'use client';
import { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { Plus, Search, Eye, FileDown, Send } from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import DataTable from '@/components/tables/DataTable';
import { PageHeader, StatusBadge } from '@/components/ui';
import { formatCurrency, formatDate, getErrorMessage } from '@/lib/utils';
import api from '@/lib/api';

const fetcher = (url: string) => api.get(url).then((r) => r.data);

export default function InvoicesPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');

  const { data, isLoading, mutate } = useSWR(
    `/invoices?page=${page}&limit=20&search=${search}&status=${status}`, fetcher,
  );

  const handleWhatsApp = async (inv: any) => {
    try {
      const { data: share } = await api.post('/import-export/prepare-send', { type: 'invoice', id: inv.id });
      window.open(share.whatsappUrl, '_blank');
    } catch (err) { toast.error(getErrorMessage(err)); }
  };

  const columns = [
    { key:'number', header:'Invoice #', render:(r:any) => <span className="font-mono text-xs font-semibold text-blue-600">{r.number}</span> },
    { key:'customer', header:'Customer', render:(r:any) => <span className="font-medium">{r.customer?.name}</span> },
    { key:'totalAmount', header:'Total', render:(r:any) => <span className="font-bold">{formatCurrency(r.totalAmount)}</span> },
    { key:'status', header:'Status', render:(r:any) => <StatusBadge status={r.status} /> },
    { key:'createdAt', header:'Date', render:(r:any) => formatDate(r.createdAt) },
    { key:'actions', header:'', render:(r:any) => (
      <div className="flex items-center gap-1">
        <Link href={`/invoices/${r.id}`} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"><Eye className="w-4 h-4" /></Link>
        {r.pdfUrl && <a href={`${process.env.NEXT_PUBLIC_API_URL}${r.pdfUrl}`} target="_blank" className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded"><FileDown className="w-4 h-4" /></a>}
        <button onClick={() => handleWhatsApp(r)} className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded"><Send className="w-4 h-4" /></button>
      </div>
    )},
  ];

  return (
    <AppShell>
      <PageHeader
        title="Invoices"
        subtitle={`${data?.meta?.total||0} invoices`}
        actions={<Link href="/invoices/new" className="btn-primary"><Plus className="w-4 h-4" />New Invoice</Link>}
      />

      <div className="flex gap-3 mb-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input className="input pl-9" placeholder="Search invoice # or customer..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        </div>
        <select className="input w-40" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All Status</option>
          <option value="PAID">Paid</option>
          <option value="UNPAID">Unpaid</option>
          <option value="PARTIAL">Partial</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
      </div>

      <DataTable columns={columns as any} data={data?.data||[]} meta={data?.meta} onPageChange={setPage} loading={isLoading} emptyMessage="No invoices found." keyExtractor={(r:any) => r.id} />
    </AppShell>
  );
}
