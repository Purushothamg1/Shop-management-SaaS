'use client';
import { useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { Plus, Search, Eye, Pencil, FileDown, Send } from 'lucide-react';
import AppShell from '@/components/layout/AppShell';
import DataTable from '@/components/tables/DataTable';
import { PageHeader, StatusBadge, Modal, FormField } from '@/components/ui';
import { formatDate, getErrorMessage } from '@/lib/utils';
import api from '@/lib/api';

const fetcher = (url: string) => api.get(url).then((r) => r.data);

const STATUSES = ['RECEIVED','DIAGNOSING','WAITING_FOR_PARTS','IN_REPAIR','READY','DELIVERED'];

export default function RepairsPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [updateModal, setUpdateModal] = useState<any>(null);
  const [updateForm, setUpdateForm] = useState({ status: '', repairNotes: '', finalCost: '' });
  const [saving, setSaving] = useState(false);

  const { data, isLoading, mutate } = useSWR(
    `/repairs?page=${page}&limit=20&search=${search}&status=${statusFilter}`, fetcher,
  );

  const openUpdate = (r: any) => {
    setUpdateModal(r);
    setUpdateForm({ status: r.status, repairNotes: r.repairNotes || '', finalCost: r.finalCost || '' });
  };

  const handleUpdate = async () => {
    setSaving(true);
    try {
      await api.put(`/repairs/${updateModal.id}`, {
        ...updateForm,
        finalCost: updateForm.finalCost ? parseFloat(updateForm.finalCost) : undefined,
      });
      toast.success('Repair updated');
      mutate();
      setUpdateModal(null);
    } catch (err) { toast.error(getErrorMessage(err)); }
    finally { setSaving(false); }
  };

  const handleWhatsApp = async (r: any) => {
    try {
      const { data: share } = await api.post('/import-export/prepare-send', { type: 'repair', id: r.id });
      window.open(share.whatsappUrl, '_blank');
    } catch (err) { toast.error(getErrorMessage(err)); }
  };

  const columns = [
    { key:'jobId', header:'Job ID', render:(r:any) => <span className="font-mono text-xs font-semibold text-blue-600">{r.jobId}</span> },
    { key:'device', header:'Device', render:(r:any) => <div><p className="font-medium">{r.brand} {r.model}</p><p className="text-xs text-gray-400">{r.deviceType}</p></div> },
    { key:'customer', header:'Customer', render:(r:any) => <span>{r.customer?.name}</span> },
    { key:'technician', header:'Technician', render:(r:any) => r.technician?.name || <span className="text-gray-300">Unassigned</span> },
    { key:'status', header:'Status', render:(r:any) => <StatusBadge status={r.status} /> },
    { key:'createdAt', header:'Date', render:(r:any) => formatDate(r.createdAt) },
    { key:'actions', header:'', render:(r:any) => (
      <div className="flex items-center gap-1">
        <Link href={`/repairs/${r.id}`} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded"><Eye className="w-4 h-4" /></Link>
        <button onClick={() => openUpdate(r)} className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded"><Pencil className="w-4 h-4" /></button>
        {r.pdfUrl && <a href={`${process.env.NEXT_PUBLIC_API_URL}${r.pdfUrl}`} target="_blank" className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded"><FileDown className="w-4 h-4" /></a>}
        <button onClick={() => handleWhatsApp(r)} className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded"><Send className="w-4 h-4" /></button>
      </div>
    )},
  ];

  return (
    <AppShell>
      <PageHeader title="Repair Jobs" subtitle={`${data?.meta?.total||0} jobs`} actions={<Link href="/repairs/new" className="btn-primary"><Plus className="w-4 h-4" />New Repair</Link>} />

      <div className="flex gap-3 mb-4">
        <div className="relative flex-1 max-w-sm"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input className="input pl-9" placeholder="Job ID, brand, model, customer..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></div>
        <select className="input w-48" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}>
          <option value="">All Statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
        </select>
      </div>

      <DataTable columns={columns as any} data={data?.data||[]} meta={data?.meta} onPageChange={setPage} loading={isLoading} emptyMessage="No repair jobs found." keyExtractor={(r:any) => r.id} />

      <Modal open={!!updateModal} onClose={() => setUpdateModal(null)} title={`Update Repair — ${updateModal?.jobId}`}>
        <div className="space-y-4">
          <FormField label="Status"><select className="input" value={updateForm.status} onChange={(e) => setUpdateForm({...updateForm, status:e.target.value})}>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}</select></FormField>
          <FormField label="Repair Notes"><textarea className="input" rows={3} value={updateForm.repairNotes} onChange={(e) => setUpdateForm({...updateForm, repairNotes:e.target.value})} /></FormField>
          <FormField label="Final Cost"><input className="input" type="number" min="0" step="0.01" value={updateForm.finalCost} onChange={(e) => setUpdateForm({...updateForm, finalCost:e.target.value})} /></FormField>
          <div className="flex gap-3 justify-end"><button onClick={() => setUpdateModal(null)} className="btn-secondary">Cancel</button><button onClick={handleUpdate} disabled={saving} className="btn-primary">{saving?'Saving...':'Update'}</button></div>
        </div>
      </Modal>
    </AppShell>
  );
}
