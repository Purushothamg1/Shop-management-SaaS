export function formatCurrency(amount: number | string, symbol = '₹'): string {
  const n = typeof amount === 'string' ? parseFloat(amount) : amount;
  return `${symbol}${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatDateTime(date: string | Date): string {
  return new Date(date).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function cn(...classes: (string | undefined | false | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export const STATUS_COLORS: Record<string, string> = {
  PAID: 'badge-green',
  UNPAID: 'badge-red',
  PARTIAL: 'badge-yellow',
  CANCELLED: 'badge-gray',
  RECEIVED: 'badge-blue',
  DIAGNOSING: 'badge-yellow',
  WAITING_FOR_PARTS: 'badge-yellow',
  IN_REPAIR: 'badge-blue',
  READY: 'badge-green',
  DELIVERED: 'badge-gray',
};

export function getErrorMessage(error: unknown): string {
  if (error && typeof error === 'object' && 'response' in error) {
    const axiosError = error as { response?: { data?: { error?: string; details?: string[] } } };
    if (axiosError.response?.data?.details?.length) return axiosError.response.data.details.join(', ');
    if (axiosError.response?.data?.error) return axiosError.response.data.error;
  }
  if (error instanceof Error) return error.message;
  return 'An unexpected error occurred';
}
