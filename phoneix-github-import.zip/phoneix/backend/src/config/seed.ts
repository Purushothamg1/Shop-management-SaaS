import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function seed() {
  console.log('Seeding database...');

  // Seed admin user
  const adminPassword = await bcrypt.hash('Admin@1234', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@phoneix.com' },
    update: {},
    create: {
      email: 'admin@phoneix.com',
      password: adminPassword,
      name: 'System Admin',
      role: 'ADMIN',
    },
  });
  console.log('Admin user created:', admin.email);

  // Seed default settings
  const settings = [
    { key: 'business_name', value: 'Phoneix Business Suite' },
    { key: 'business_address', value: '123 Main Street, City' },
    { key: 'business_phone', value: '+91 9999999999' },
    { key: 'business_email', value: 'info@phoneix.com' },
    { key: 'gst_number', value: 'GSTIN0000000000' },
    { key: 'invoice_prefix', value: 'INV' },
    { key: 'default_tax', value: '18' },
    { key: 'currency', value: 'INR' },
    { key: 'currency_symbol', value: '₹' },
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }
  console.log('Settings seeded');

  console.log('Seeding complete!');
  console.log('\nDefault credentials:');
  console.log('  Email: admin@phoneix.com');
  console.log('  Password: Admin@1234');
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
