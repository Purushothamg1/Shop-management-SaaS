import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';
import { prisma } from '../../config/database';
import { NotFoundError } from '../../shared/errors/AppError';

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';
const PDF_DIR = path.join(UPLOAD_DIR, 'pdfs');

function ensureDir(dir: string) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

async function getBusinessSettings() {
  const settings = await prisma.setting.findMany();
  return settings.reduce((acc: Record<string, string>, s) => {
    acc[s.key] = s.value;
    return acc;
  }, {});
}

export const pdfService = {
  async generateInvoicePdf(invoiceId: string): Promise<string> {
    const invoice = await prisma.invoice.findUnique({
      where: { id: invoiceId },
      include: { customer: true, items: { include: { product: true } }, payments: true },
    });
    if (!invoice) throw new NotFoundError('Invoice');

    const settings = await getBusinessSettings();
    ensureDir(PDF_DIR);
    const filename = `invoice-${invoice.number}.pdf`;
    const filepath = path.join(PDF_DIR, filename);

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 50 });
      const stream = fs.createWriteStream(filepath);
      doc.pipe(stream);

      // Header
      doc.fontSize(22).font('Helvetica-Bold').text(settings.business_name || 'Business', 50, 50);
      doc.fontSize(9).font('Helvetica')
        .text(settings.business_address || '', 50, 80)
        .text(`Phone: ${settings.business_phone || ''}`)
        .text(`GST: ${settings.gst_number || ''}`);

      // Invoice Title
      doc.fontSize(18).font('Helvetica-Bold').text('INVOICE', 400, 50, { align: 'right' });
      doc.fontSize(10).font('Helvetica')
        .text(`Invoice #: ${invoice.number}`, 400, 80, { align: 'right' })
        .text(`Date: ${invoice.createdAt.toLocaleDateString()}`, { align: 'right' })
        .text(`Status: ${invoice.status}`, { align: 'right' });

      // Customer info
      doc.moveDown(2).fontSize(11).font('Helvetica-Bold').text('Bill To:');
      doc.fontSize(10).font('Helvetica')
        .text(invoice.customer.name)
        .text(invoice.customer.phone)
        .text(invoice.customer.email || '');

      // Table header
      const tableTop = 220;
      const currency = settings.currency_symbol || '₹';
      doc.moveDown();
      doc.rect(50, tableTop, 495, 20).fill('#f0f0f0');
      doc.fillColor('black').fontSize(9).font('Helvetica-Bold');
      doc.text('Description', 55, tableTop + 5);
      doc.text('Qty', 280, tableTop + 5);
      doc.text('Unit Price', 330, tableTop + 5);
      doc.text('Tax%', 410, tableTop + 5);
      doc.text('Total', 460, tableTop + 5);

      // Table rows
      let y = tableTop + 25;
      doc.font('Helvetica').fontSize(9).fillColor('black');
      for (const item of invoice.items) {
        doc.text(item.description.substring(0, 35), 55, y);
        doc.text(item.qty.toString(), 280, y);
        doc.text(`${currency}${Number(item.unitPrice).toFixed(2)}`, 330, y);
        doc.text(`${Number(item.tax)}%`, 410, y);
        doc.text(`${currency}${Number(item.total).toFixed(2)}`, 460, y);
        y += 18;
        if (y > 700) { doc.addPage(); y = 50; }
      }

      // Totals
      doc.moveTo(50, y + 5).lineTo(545, y + 5).stroke();
      y += 15;
      const subtotal = Number(invoice.totalAmount) - Number(invoice.taxAmount) + Number(invoice.discount);
      doc.font('Helvetica').fontSize(10);
      doc.text(`Subtotal: ${currency}${subtotal.toFixed(2)}`, 350, y);
      doc.text(`Tax: ${currency}${Number(invoice.taxAmount).toFixed(2)}`, 350, y + 15);
      if (Number(invoice.discount) > 0) doc.text(`Discount: -${currency}${Number(invoice.discount).toFixed(2)}`, 350, y + 30);
      doc.font('Helvetica-Bold').text(`TOTAL: ${currency}${Number(invoice.totalAmount).toFixed(2)}`, 350, y + 50);

      doc.end();
      stream.on('finish', () => resolve(`/uploads/pdfs/${filename}`));
      stream.on('error', reject);
    });
  },

  async generateRepairPdf(repairId: string): Promise<string> {
    const repair = await prisma.repairJob.findUnique({
      where: { id: repairId },
      include: { customer: true, technician: true, parts: { include: { product: true } } },
    });
    if (!repair) throw new NotFoundError('Repair job');

    const settings = await getBusinessSettings();
    ensureDir(PDF_DIR);
    const filename = `repair-${repair.jobId}.pdf`;
    const filepath = path.join(PDF_DIR, filename);

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: 50 });
      const stream = fs.createWriteStream(filepath);
      doc.pipe(stream);

      doc.fontSize(20).font('Helvetica-Bold').text(settings.business_name || 'Service Center', { align: 'center' });
      doc.fontSize(14).text('REPAIR JOB CARD', { align: 'center' });
      doc.moveDown();

      doc.fontSize(10).font('Helvetica-Bold').text('Job ID: ', { continued: true }).font('Helvetica').text(repair.jobId);
      doc.font('Helvetica-Bold').text('Date: ', { continued: true }).font('Helvetica').text(repair.createdAt.toLocaleDateString());
      doc.font('Helvetica-Bold').text('Status: ', { continued: true }).font('Helvetica').text(repair.status);
      doc.moveDown();

      doc.fontSize(11).font('Helvetica-Bold').text('Customer Information');
      doc.fontSize(10).font('Helvetica')
        .text(`Name: ${repair.customer.name}`)
        .text(`Phone: ${repair.customer.phone}`);
      doc.moveDown();

      doc.fontSize(11).font('Helvetica-Bold').text('Device Information');
      doc.fontSize(10).font('Helvetica')
        .text(`Device Type: ${repair.deviceType}`)
        .text(`Brand: ${repair.brand}`)
        .text(`Model: ${repair.model}`)
        .text(`Serial Number: ${repair.serialNumber || 'N/A'}`);
      doc.moveDown();

      doc.fontSize(11).font('Helvetica-Bold').text('Issue Description');
      doc.fontSize(10).font('Helvetica').text(repair.issueDescription);
      doc.moveDown();

      if (repair.parts.length > 0) {
        const currency = settings.currency_symbol || '₹';
        doc.fontSize(11).font('Helvetica-Bold').text('Parts Used');
        for (const part of repair.parts) {
          doc.fontSize(10).font('Helvetica')
            .text(`${part.product.name} x${part.qty} @ ${currency}${Number(part.cost).toFixed(2)}`);
        }
        doc.moveDown();
      }

      if (repair.estimatedCost) {
        const currency = settings.currency_symbol || '₹';
        doc.font('Helvetica-Bold').text(`Estimated Cost: ${currency}${Number(repair.estimatedCost).toFixed(2)}`);
      }

      doc.moveDown(3).fontSize(9).font('Helvetica').text('Customer Signature: ___________________________', 50);
      doc.text('Technician Signature: ___________________________', 300, doc.y - 12);

      doc.end();
      stream.on('finish', () => resolve(`/uploads/pdfs/${filename}`));
      stream.on('error', reject);
    });
  },
};
