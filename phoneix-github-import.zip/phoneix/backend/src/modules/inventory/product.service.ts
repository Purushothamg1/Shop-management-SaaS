import { MovementType } from '@prisma/client';
import { prisma } from '../../config/database';
import { NotFoundError, ConflictError, ValidationError } from '../../shared/errors/AppError';
import { getPaginationParams, buildPaginatedResult } from '../../shared/utils/pagination';

export const productService = {
  async list(query: Record<string, string>) {
    const { page, limit, skip } = getPaginationParams(query);
    const where: any = {};
    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { sku: { contains: query.search, mode: 'insensitive' } },
        { barcode: { contains: query.search } },
      ];
    }
    if (query.category) where.category = { equals: query.category, mode: 'insensitive' };

    const [data, total] = await Promise.all([
      prisma.product.findMany({ where, skip, take: limit, orderBy: { name: 'asc' } }),
      prisma.product.count({ where }),
    ]);
    return buildPaginatedResult(data, total, { page, limit, skip });
  },

  async lowStock() {
    return prisma.product.findMany({
      where: { stockQty: { lte: prisma.product.fields.minStockLevel } },
      orderBy: { stockQty: 'asc' },
    });
  },

  async create(data: any) {
    const existingSku = await prisma.product.findUnique({ where: { sku: data.sku } });
    if (existingSku) throw new ConflictError('Product with this SKU already exists');
    if (data.barcode) {
      const existingBarcode = await prisma.product.findUnique({ where: { barcode: data.barcode } });
      if (existingBarcode) throw new ConflictError('Product with this barcode already exists');
    }
    return prisma.product.create({ data });
  },

  async getById(id: string) {
    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) throw new NotFoundError('Product');
    return product;
  },

  async update(id: string, data: any) {
    await this.getById(id);
    const dupSku = await prisma.product.findFirst({ where: { sku: data.sku, NOT: { id } } });
    if (dupSku) throw new ConflictError('Another product with this SKU exists');
    return prisma.product.update({ where: { id }, data });
  },

  async remove(id: string) {
    await this.getById(id);
    return prisma.product.delete({ where: { id } });
  },

  async adjustStock(id: string, quantity: number, movementType: MovementType, note?: string) {
    const product = await this.getById(id);
    const newQty = product.stockQty + quantity;
    if (newQty < 0) throw new ValidationError('Stock adjustment would result in negative stock');

    const [updated] = await prisma.$transaction([
      prisma.product.update({ where: { id }, data: { stockQty: newQty } }),
      prisma.stockMovement.create({ data: { productId: id, movementType, quantity, note } }),
    ]);
    return updated;
  },

  async getMovements(id: string, query: Record<string, string>) {
    await this.getById(id);
    const { page, limit, skip } = getPaginationParams(query);
    const [data, total] = await Promise.all([
      prisma.stockMovement.findMany({
        where: { productId: id },
        skip, take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.stockMovement.count({ where: { productId: id } }),
    ]);
    return buildPaginatedResult(data, total, { page, limit, skip });
  },
};
