import { Router } from 'express';
import { Request, Response, NextFunction } from 'express';
import { authenticate } from '../../shared/middleware/auth.middleware';
import { prisma } from '../../config/database';

export const dashboardRouter = Router();
dashboardRouter.use(authenticate);

dashboardRouter.get('/', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    const [
      todaySales,
      monthlyRevenue,
      activeRepairs,
      lowStock,
      recentInvoices,
      recentRepairs,
      salesByDay,
    ] = await Promise.all([
      prisma.invoice.aggregate({
        where: { createdAt: { gte: today, lte: todayEnd }, status: { not: 'CANCELLED' } },
        _sum: { totalAmount: true },
        _count: true,
      }),
      prisma.invoice.aggregate({
        where: { createdAt: { gte: monthStart }, status: { not: 'CANCELLED' } },
        _sum: { totalAmount: true },
        _count: true,
      }),
      prisma.repairJob.count({
        where: { status: { notIn: ['DELIVERED'] } },
      }),
      prisma.product.count({
        where: { stockQty: { lte: prisma.product.fields.minStockLevel } },
      }),
      prisma.invoice.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { customer: { select: { name: true } } },
      }),
      prisma.repairJob.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        where: { status: { notIn: ['DELIVERED'] } },
        include: { customer: { select: { name: true } } },
      }),
      prisma.$queryRaw`
        SELECT DATE(created_at) as date, SUM(total_amount) as total
        FROM "Invoice"
        WHERE created_at >= ${monthStart} AND status != 'CANCELLED'
        GROUP BY DATE(created_at)
        ORDER BY date ASC
      `,
    ]);

    res.json({
      todaySales: {
        amount: todaySales._sum.totalAmount || 0,
        count: todaySales._count,
      },
      monthlyRevenue: {
        amount: monthlyRevenue._sum.totalAmount || 0,
        count: monthlyRevenue._count,
      },
      activeRepairs,
      lowStockAlerts: lowStock,
      recentInvoices,
      recentRepairs,
      salesByDay,
    });
  } catch (e) { next(e); }
});
