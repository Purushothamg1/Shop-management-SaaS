import { prisma } from '../../config/database';
import { NotFoundError } from '../../shared/errors/AppError';
import { getPaginationParams, buildPaginatedResult } from '../../shared/utils/pagination';
import { pdfService } from '../pdf/pdf.service';

async function generateJobId(): Promise<string> {
  const count = await prisma.repairJob.count();
  return `JOB-${String(count + 1).padStart(5, '0')}`;
}

export const repairService = {
  async list(query: Record<string, string>) {
    const { page, limit, skip } = getPaginationParams(query);
    const where: any = {};
    if (query.status) where.status = query.status;
    if (query.technicianId) where.technicianId = query.technicianId;
    if (query.customerId) where.customerId = query.customerId;
    if (query.search) {
      where.OR = [
        { jobId: { contains: query.search, mode: 'insensitive' } },
        { brand: { contains: query.search, mode: 'insensitive' } },
        { model: { contains: query.search, mode: 'insensitive' } },
        { customer: { name: { contains: query.search, mode: 'insensitive' } } },
      ];
    }
    const [data, total] = await Promise.all([
      prisma.repairJob.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: { select: { id: true, name: true, phone: true } },
          technician: { select: { id: true, name: true } },
          parts: { include: { product: { select: { name: true } } } },
        },
      }),
      prisma.repairJob.count({ where }),
    ]);
    return buildPaginatedResult(data, total, { page, limit, skip });
  },

  async create(data: any) {
    const jobId = await generateJobId();
    const { parts, ...jobData } = data;

    const repair = await prisma.$transaction(async (tx) => {
      const job = await tx.repairJob.create({
        data: {
          ...jobData,
          jobId,
          parts: parts?.length ? {
            create: parts.map((p: any) => ({
              productId: p.productId,
              qty: p.qty,
              cost: p.cost,
            })),
          } : undefined,
        },
        include: { customer: true, technician: true, parts: { include: { product: true } } },
      });

      // Deduct stock for parts
      if (parts?.length) {
        for (const part of parts) {
          await tx.product.update({
            where: { id: part.productId },
            data: { stockQty: { decrement: part.qty } },
          });
          await tx.stockMovement.create({
            data: {
              productId: part.productId,
              movementType: 'REPAIR_USAGE',
              quantity: -part.qty,
              note: `Repair ${jobId}`,
            },
          });
        }
      }
      return job;
    });

    // Generate PDF
    try {
      const pdfUrl = await pdfService.generateRepairPdf(repair.id);
      await prisma.repairJob.update({ where: { id: repair.id }, data: { pdfUrl } });
      return { ...repair, pdfUrl };
    } catch {
      return repair;
    }
  },

  async getById(id: string) {
    const repair = await prisma.repairJob.findUnique({
      where: { id },
      include: {
        customer: true,
        technician: true,
        parts: { include: { product: true } },
      },
    });
    if (!repair) throw new NotFoundError('Repair job');
    return repair;
  },

  async update(id: string, data: any) {
    await this.getById(id);
    const repair = await prisma.repairJob.update({
      where: { id },
      data,
      include: { customer: true, technician: true, parts: { include: { product: true } } },
    });
    return repair;
  },

  async remove(id: string) {
    await this.getById(id);
    return prisma.repairJob.delete({ where: { id } });
  },
};
