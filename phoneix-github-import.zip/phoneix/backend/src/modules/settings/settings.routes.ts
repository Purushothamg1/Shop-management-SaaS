import { Router } from 'express';
import { Request, Response, NextFunction } from 'express';
import { authenticate, authorize } from '../../shared/middleware/auth.middleware';
import { prisma } from '../../config/database';

export const settingsRouter = Router();
settingsRouter.use(authenticate);

settingsRouter.get('/', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const settings = await prisma.setting.findMany();
    const obj = settings.reduce((acc: Record<string, string>, s) => {
      acc[s.key] = s.value;
      return acc;
    }, {});
    res.json(obj);
  } catch (e) { next(e); }
});

settingsRouter.put('/', authorize('ADMIN'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    const updates: Record<string, string> = req.body;
    const ops = Object.entries(updates).map(([key, value]) =>
      prisma.setting.upsert({
        where: { key },
        update: { value: String(value) },
        create: { key, value: String(value) },
      })
    );
    await Promise.all(ops);
    const settings = await prisma.setting.findMany();
    const obj = settings.reduce((acc: Record<string, string>, s) => {
      acc[s.key] = s.value;
      return acc;
    }, {});
    res.json(obj);
  } catch (e) { next(e); }
});
