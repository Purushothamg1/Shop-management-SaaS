import { Router } from 'express';
import multer from 'multer';
import { Request, Response, NextFunction } from 'express';
import { authenticate, authorize } from '../../shared/middleware/auth.middleware';
import { prisma } from '../../config/database';
import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';

export const importExportRouter = Router();
importExportRouter.use(authenticate, authorize('ADMIN', 'MANAGER'));

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// Import products from CSV/Excel
importExportRouter.post('/products/import', upload.single('file'), async (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!req.file) { res.status(400).json({ error: 'No file uploaded' }); return; }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet) as Record<string, any>[];

    const results = { imported: 0, skipped: 0, errors: [] as string[] };

    for (const row of rows) {
      try {
        const sku = String(row.sku || row.SKU || '').trim();
        if (!sku) { results.errors.push(`Row missing SKU`); results.skipped++; continue; }

        await prisma.product.upsert({
          where: { sku },
          update: {
            name: String(row.name || row.Name || ''),
            category: String(row.category || row.Category || ''),
            purchasePrice: parseFloat(row.purchasePrice || row.purchase_price || 0),
            sellingPrice: parseFloat(row.sellingPrice || row.selling_price || 0),
            stockQty: parseInt(row.stockQty || row.stock_qty || 0),
            minStockLevel: parseInt(row.minStockLevel || row.min_stock || 5),
          },
          create: {
            sku,
            name: String(row.name || row.Name || 'Unnamed'),
            category: String(row.category || row.Category || ''),
            purchasePrice: parseFloat(row.purchasePrice || row.purchase_price || 0),
            sellingPrice: parseFloat(row.sellingPrice || row.selling_price || 0),
            stockQty: parseInt(row.stockQty || row.stock_qty || 0),
            minStockLevel: parseInt(row.minStockLevel || row.min_stock || 5),
          },
        });
        results.imported++;
      } catch (err) {
        results.skipped++;
        results.errors.push(`Error on row: ${JSON.stringify(row)}`);
      }
    }

    res.json(results);
  } catch (e) { next(e); }
});

// Export products to Excel
importExportRouter.get('/products/export', async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const products = await prisma.product.findMany({ orderBy: { name: 'asc' } });
    const data = products.map((p) => ({
      SKU: p.sku,
      Name: p.name,
      Category: p.category || '',
      Barcode: p.barcode || '',
      'Purchase Price': Number(p.purchasePrice),
      'Selling Price': Number(p.sellingPrice),
      'Stock Qty': p.stockQty,
      'Min Stock Level': p.minStockLevel,
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, 'Products');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=products-export.xlsx');
    res.send(buf);
  } catch (e) { next(e); }
});

// Export sales report to Excel
importExportRouter.get('/reports/sales/export', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const from = req.query.from ? new Date(req.query.from as string) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const to = req.query.to ? new Date(req.query.to as string) : new Date();

    const invoices = await prisma.invoice.findMany({
      where: { createdAt: { gte: from, lte: to }, status: { not: 'CANCELLED' } },
      include: { customer: { select: { name: true, phone: true } } },
      orderBy: { createdAt: 'desc' },
    });

    const data = invoices.map((inv) => ({
      'Invoice #': inv.number,
      Customer: inv.customer.name,
      Phone: inv.customer.phone,
      Status: inv.status,
      'Tax Amount': Number(inv.taxAmount),
      Discount: Number(inv.discount),
      Total: Number(inv.totalAmount),
      Date: inv.createdAt.toLocaleDateString(),
    }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data), 'Sales');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=sales-report.xlsx');
    res.send(buf);
  } catch (e) { next(e); }
});

// WhatsApp share endpoint
importExportRouter.post('/prepare-send', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { type, id } = req.body;
    let pdfUrl = '';
    let phone = '';

    if (type === 'invoice') {
      const invoice = await prisma.invoice.findUnique({
        where: { id }, include: { customer: true },
      });
      if (!invoice) { res.status(404).json({ error: 'Invoice not found' }); return; }
      pdfUrl = invoice.pdfUrl || '';
      phone = invoice.customer.phone;
    } else if (type === 'repair') {
      const repair = await prisma.repairJob.findUnique({
        where: { id }, include: { customer: true },
      });
      if (!repair) { res.status(404).json({ error: 'Repair not found' }); return; }
      pdfUrl = repair.pdfUrl || '';
      phone = repair.customer.phone;
    }

    const whatsappUrl = `https://wa.me/${phone.replace(/\D/g, '')}`;
    res.json({ pdfUrl, whatsappUrl, phone });
  } catch (e) { next(e); }
});
