// ============================================================
// PAYMENT ROUTES
// ============================================================
import { Router } from 'express';
import { celebrate, Joi, Segments } from 'celebrate';
import { Request, Response, NextFunction } from 'express';
import { authenticate } from '../../shared/middleware/auth.middleware';
import { prisma } from '../../config/database';
import { NotFoundError, ValidationError } from '../../shared/errors/AppError';

export const paymentRouter = Router();
paymentRouter.use(authenticate);

const paymentSchema = Joi.object({
  invoiceId: Joi.string().uuid().required(),
  amount: Joi.number().positive().required(),
  method: Joi.string().valid('CASH', 'UPI', 'CARD', 'BANK_TRANSFER').required(),
});

async function updateInvoiceStatus(invoiceId: string, tx: any) {
  const invoice = await tx.invoice.findUnique({
    where: { id: invoiceId },
    include: { payments: { where: { refunded: false } } },
  });
  if (!invoice) return;

  const paid = invoice.payments.reduce(
    (sum: number, p: any) => sum + parseFloat(p.amount.toString()),
    0,
  );
  const total = parseFloat(invoice.totalAmount.toString());

  let status = 'UNPAID';
  if (paid >= total) status = 'PAID';
  else if (paid > 0) status = 'PARTIAL';

  await tx.invoice.update({ where: { id: invoiceId }, data: { status } });
}

paymentRouter.post(
  '/',
  celebrate({ [Segments.BODY]: paymentSchema }),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { invoiceId, amount, method } = req.body;
      const invoice = await prisma.invoice.findUnique({ where: { id: invoiceId } });
      if (!invoice) throw new NotFoundError('Invoice');
      if (invoice.status === 'CANCELLED') throw new ValidationError('Cannot pay a cancelled invoice');
      if (invoice.status === 'PAID') throw new ValidationError('Invoice is already fully paid');

      const payment = await prisma.$transaction(async (tx) => {
        const p = await tx.payment.create({ data: { invoiceId, amount, method } });
        await updateInvoiceStatus(invoiceId, tx);
        return p;
      });
      res.status(201).json(payment);
    } catch (e) { next(e); }
  },
);

paymentRouter.post(
  '/refund',
  celebrate({ [Segments.BODY]: Joi.object({ paymentId: Joi.string().uuid().required() }) }),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { paymentId } = req.body;
      const payment = await prisma.payment.findUnique({ where: { id: paymentId } });
      if (!payment) throw new NotFoundError('Payment');
      if (payment.refunded) throw new ValidationError('Payment already refunded');

      const updated = await prisma.$transaction(async (tx) => {
        const p = await tx.payment.update({ where: { id: paymentId }, data: { refunded: true } });
        await updateInvoiceStatus(payment.invoiceId, tx);
        return p;
      });
      res.json(updated);
    } catch (e) { next(e); }
  },
);

paymentRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { invoiceId } = req.query;
    const where: any = {};
    if (invoiceId) where.invoiceId = invoiceId;
    const payments = await prisma.payment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: { invoice: { select: { number: true, customer: { select: { name: true } } } } },
    });
    res.json(payments);
  } catch (e) { next(e); }
});
