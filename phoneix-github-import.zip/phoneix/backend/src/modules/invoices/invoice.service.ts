import { prisma } from '../../config/database';
import { NotFoundError, ValidationError } from '../../shared/errors/AppError';
import { getPaginationParams, buildPaginatedResult } from '../../shared/utils/pagination';
import { pdfService } from '../pdf/pdf.service';

interface InvoiceItemInput {
  productId?: string;
  description: string;
  qty: number;
  unitPrice: number;
  tax?: number;
}

interface CreateInvoiceInput {
  customerId: string;
  discount?: number;
  items: InvoiceItemInput[];
}

async function generateInvoiceNumber(): Promise<string> {
  const setting = await prisma.setting.findUnique({ where: { key: 'invoice_prefix' } });
  const prefix = setting?.value || 'INV';
  const count = await prisma.invoice.count();
  return `${prefix}-${String(count + 1).padStart(5, '0')}`;
}

export const invoiceService = {
  async list(query: Record<string, string>) {
    const { page, limit, skip } = getPaginationParams(query);
    const where: any = {};
    if (query.status) where.status = query.status;
    if (query.customerId) where.customerId = query.customerId;
    if (query.search) {
      where.OR = [
        { number: { contains: query.search, mode: 'insensitive' } },
        { customer: { name: { contains: query.search, mode: 'insensitive' } } },
      ];
    }
    const [data, total] = await Promise.all([
      prisma.invoice.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: { customer: { select: { id: true, name: true, phone: true } }, items: true, payments: true },
      }),
      prisma.invoice.count({ where }),
    ]);
    return buildPaginatedResult(data, total, { page, limit, skip });
  },

  async create(data: CreateInvoiceInput) {
    const customer = await prisma.customer.findUnique({ where: { id: data.customerId } });
    if (!customer) throw new NotFoundError('Customer');

    // Validate stock for product items
    for (const item of data.items) {
      if (item.productId) {
        const product = await prisma.product.findUnique({ where: { id: item.productId } });
        if (!product) throw new NotFoundError(`Product ${item.productId}`);
        if (product.stockQty < item.qty) {
          throw new ValidationError(`Insufficient stock for "${product.name}". Available: ${product.stockQty}`);
        }
      }
    }

    const number = await generateInvoiceNumber();
    const taxSetting = await prisma.setting.findUnique({ where: { key: 'default_tax' } });
    const defaultTax = parseFloat(taxSetting?.value || '0');

    let subtotal = 0;
    let taxAmount = 0;
    const itemsData = data.items.map((item) => {
      const itemTax = item.tax ?? defaultTax;
      const lineSubtotal = item.qty * item.unitPrice;
      const lineTax = lineSubtotal * (itemTax / 100);
      const total = lineSubtotal + lineTax;
      subtotal += lineSubtotal;
      taxAmount += lineTax;
      return {
        productId: item.productId || null,
        description: item.description,
        qty: item.qty,
        unitPrice: item.unitPrice,
        tax: itemTax,
        total,
      };
    });

    const discount = data.discount || 0;
    const totalAmount = subtotal + taxAmount - discount;

    const invoice = await prisma.$transaction(async (tx) => {
      const created = await tx.invoice.create({
        data: {
          number,
          customerId: data.customerId,
          taxAmount,
          discount,
          totalAmount,
          status: 'UNPAID',
          items: { create: itemsData },
        },
        include: { items: true, customer: true, payments: true },
      });

      // Reduce stock and record movement for product items
      for (const item of data.items) {
        if (item.productId) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stockQty: { decrement: item.qty } },
          });
          await tx.stockMovement.create({
            data: {
              productId: item.productId,
              movementType: 'SALE',
              quantity: -item.qty,
              note: `Invoice ${number}`,
            },
          });
        }
      }
      return created;
    });

    // Generate PDF
    try {
      const pdfUrl = await pdfService.generateInvoicePdf(invoice.id);
      await prisma.invoice.update({ where: { id: invoice.id }, data: { pdfUrl } });
      return { ...invoice, pdfUrl };
    } catch {
      return invoice;
    }
  },

  async getById(id: string) {
    const invoice = await prisma.invoice.findUnique({
      where: { id },
      include: {
        customer: true,
        items: { include: { product: true } },
        payments: true,
      },
    });
    if (!invoice) throw new NotFoundError('Invoice');
    return invoice;
  },

  async update(id: string, data: { discount?: number; status?: string }) {
    const invoice = await this.getById(id);
    if (invoice.status === 'CANCELLED') throw new ValidationError('Cannot update a cancelled invoice');
    return prisma.invoice.update({ where: { id }, data });
  },

  async cancel(id: string) {
    const invoice = await this.getById(id);
    if (invoice.status === 'CANCELLED') throw new ValidationError('Invoice already cancelled');

    await prisma.$transaction(async (tx) => {
      await tx.invoice.update({ where: { id }, data: { status: 'CANCELLED' } });
      // Restore stock
      for (const item of invoice.items) {
        if (item.productId) {
          await tx.product.update({
            where: { id: item.productId },
            data: { stockQty: { increment: item.qty } },
          });
          await tx.stockMovement.create({
            data: {
              productId: item.productId,
              movementType: 'RETURN',
              quantity: item.qty,
              note: `Cancelled Invoice ${invoice.number}`,
            },
          });
        }
      }
    });
    return prisma.invoice.findUnique({ where: { id } });
  },
};
